**To delete a private certificate authority**

The ``delete-certificate-authority`` command ::

  aws acm-pca delete-certificate-authority --certificate-authority-arn arn:aws:acm-pca:us-east-1:account:certificate-authority/12345678-1234-1234-1234-123456789012