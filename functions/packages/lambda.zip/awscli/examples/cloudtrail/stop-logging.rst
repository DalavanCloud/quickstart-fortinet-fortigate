**To stop logging a trail**

The following ``stop-logging`` command turns off logging for ``Trail1``::

  aws cloudtrail stop-logging --name Trail1
