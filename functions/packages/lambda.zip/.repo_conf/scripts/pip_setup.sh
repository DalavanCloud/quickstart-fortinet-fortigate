#!/bin/bash
cd $FTK_REPO_HOME/aws_lambda_autoscale/
virtualenv venv
source venv/bin/activate
pip install --upgrade pip setuptools
pip install -r requirements.txt
