#!/usr/bin/env bash


send_scheduled ()
{
    curl -vik --request POST --url http://127.0.0.1:8000 \
    --header 'x-amz-sns-message-type: Notification' \
    --header 'x-amz-sns-message-id: 30e629d4-be84-45d9-8033-eec459d065a8' \
    --header 'x-amz-sns-topic-arn: arn:aws:sns:us-west-1:123073262904:mdw-lambda-autoscale-FgtScEvt' \
    --header 'x-amz-sns-subscription-arn: arn:aws:sns:us-west-1:123073262904:mdw-lambda-autoscale-FgtScEvt:047214ab-3110-428b-a931-0d79ffd68be0' \
    --header 'Content-Type: text/plain; charset=UTF-8' \
    --header 'Connection: Keep-Alive' \
    --header 'User-Agent: Amazon Simple Notification Service Agent' \
    --header 'Accept-Encoding: gzip,deflate' \
    --data '{
              "Type" : "Notification",
              "MessageId" : "1ea7fb50-7f0b-57d3-b6de-a87cade34aea",
              "TopicArn" : "arn:aws:sns:us-west-1:123073262904:mdw-lambda-autoscale-FgtScEvt",
              "Subject" : "Auto Scaling: test notification for group \"mdw-lambda-autoscale-ASG1-10GBWVR2OO5YS\"",
              "Message" : "{\"AccountId\":\"123073262904\",\"RequestId\":\"16dc73ed-2d50-11e8-859c-139362710439\",\"AutoScalingGroupARN\":\"arn:aws:autoscaling:us-west-1:123073262904:autoScalingGroup:842dbe8e-1c3b-412e-9c11-092d59df2f91:autoScalingGroupName/mdw-lambda-autoscale-ASG1-10GBWVR2OO5YS\",\"AutoScalingGroupName\":\"mdw-lambda-autoscale-ASG1-10GBWVR2OO5YS\",\"Service\":\"AWS Auto Scaling\",\"Event\":\"autoscaling:TEST_NOTIFICATION\",\"Time\":\"2018-03-21T21:37:43.954Z\"}",
              "Timestamp" : "2018-03-21T21:37:44.166Z",
              "SignatureVersion" : "1",
              "Signature" : "KBuAeg70RRtZ7ephlmeKyuLvcI/mO9ro5ceyR6r9QOOLI9WpfbhvG0CPoYHuU5g/aplTNH0H7ZlI2sR2y+Gx6pnaaHQw2DZBVd7zXaYIc5KfhIGXowUvg3e8hIBQfOzD/kmzoMUzYzccMNqynrdhEAgmeoC67Wy1K5oUUFopXaGUqcYucbSJGc3MK38JoK6j6C0aoC8Y10Mz3+kIhu7d820KZgGus+JuqmTOkOiCHjCEbgOPcLdJzUdW7wYflUXgSl//ypdk23fmXL14jBYZ19gUSN0UY44kh6VbnK28Mp9OqamLYmkdecEDt2cj3FjvaHDTIC1m2PrMSe/yLdpGWw==",
              "SigningCertURL" : "https://sns.us-west-1.amazonaws.com/SimpleNotificationService-433026a4050d206028891664da859041.pem",
              "UnsubscribeURL" : "https://sns.us-west-1.amazonaws.com/?Action=Unsubscribe&SubscriptionArn=arn:aws:sns:us-west-1:123073262904:mdw-lambda-autoscale-FgtScEvt:acf38e80-b9b4-4514-a7f4-b5bdb58cb9d3"
            }'
}

send_subscribe ()
{
    curl -vik --request POST --http1.1 --url http://127.0.0.1:8000/sns \
    --header 'x-amz-sns-message-type: SubscriptionConfirmation' \
    --header 'x-amz-sns-message-id: 30e629d4-be84-45d9-8033-eec459d065a8' \
    --header 'x-amz-sns-topic-arn: arn:aws:sns:us-west-1:123073262904:mdw-lambda-autoscale-FgtScEvt' \
    --header 'x-amz-sns-subscription-arn: arn:aws:sns:us-west-1:123073262904:mdw-lambda-autoscale-FgtScEvt:047214ab-3110-428b-a931-0d79ffd68be0' \
    --header 'Content-Type: text/plain; charset=UTF-8' \
    --header 'Connection: Keep-Alive' \
    --header 'User-Agent: Amazon Simple Notification Service Agent' \
    --header 'Accept-Encoding: gzip,deflate' \
    --data '{ "Type" : "SubscriptionConfirmation",
      "MessageId" : "30e629d4-be84-45d9-8033-eec459d065a8",
      "Token" : "2336412f37fb687f5d51e6e241da92fd76847fb84f3bf2c3d4cf8c8fd7452ee7ffa9e5944fcabfc16e037029411ebbdf3c3c9fa286575f7e9a48443ea51e89aabcc2a7bf6090b9610438750cb235839dbd72ca9b92c09fa1f43efa50ecaabcbdbbe9100d3e42f25679e7bc460a698338730ed465ae9cf789bca518b097a57801",
      "TopicArn" : "arn:aws:sns:us-west-1:123073262904:mdw-lambda-autoscale-FgtScEvt",
      "Message" : "You have chosen to subscribe to the topic arn:aws:sns:us-west-1:123073262904:mdw-lambda-autoscale-FgtScEvt.\nTo confirm the subscriptionDataBuilder, visit the SubscribeURL included in this message.",
      "SubscribeURL" : "https://sns.us-west-1.amazonaws.com/?Action=ConfirmSubscription&TopicArn=arn:aws:sns:us-west-1:123073262904:mdw-lambda-autoscale-FgtScEvt&Token=2336412f37fb687f5d51e6e241da92fd76847fb84f3bf2c3d4cf8c8fd7452ee7ffa9e5944fcabfc16e037029411ebbdf3c3c9fa286575f7e9a48443ea51e89aabcc2a7bf6090b9610438750cb235839dbd72ca9b92c09fa1f43efa50ecaabcbdbbe9100d3e42f25679e7bc460a698338730ed465ae9cf789bca518b097a57801",
      "Timestamp" : "2018-03-19T16:57:18.353Z",
      "SignatureVersion" : "1",
      "Signature" : "D0Df5ecJ9THLD8w87Yjpn3QUDfUFxJc5qmGl8kcr8mctGZuUSPHYVUIydvTsf7oyKsXDKcMnemt9NvPGf7c/0G6x3mQonm1q8DVQDLRIRGjsKgshD9k1o3pqVUgpyD452kXcnU9r94ax2dnv5DBfaGStuzSxLclfVmNqAfbeCNRqI9PzuNsmH6i5QbReLD47D2wmX74x2V0vpyODZ8hkXYho8CSAg2BSirkpV3iVxITt+/OZZvNnHkzSc3QjuR92KJ1Wm8FHiPqpFVo4y8Oy2tw+2pmvVL1uZ46qXY0tIv4i85e29ZW/EmA9usQ/xPRn5qWeNU9Bzx5mmKMYvl+wyg==",
      "SigningCertURL" : "https://sns.us-west-1.amazonaws.com/SimpleNotificationService-433026a4050d206028891664da859041.pem" }'
}

send_lch_launch ()
{
    curl -vik --request POST --url http://127.0.0.1:8000/sns \
    --header 'x-amz-sns-message-type: Notification' \
    --header 'x-amz-sns-message-id: 30e629d4-be84-45d9-8033-eec459d065a8' \
    --header 'x-amz-sns-topic-arn: arn:aws:sns:us-west-1:123073262904:mdw-lambda-autoscale-FgtScEvt' \
    --header 'x-amz-sns-subscription-arn: arn:aws:sns:us-west-1:123073262904:mdw-lambda-autoscale-FgtScEvt:047214ab-3110-428b-a931-0d79ffd68be0' \
    --header 'Content-Type: text/plain; charset=UTF-8' \
    --header 'Connection: Keep-Alive' \
    --header 'User-Agent: Amazon Simple Notification Service Agent' \
    --header 'Accept-Encoding: gzip,deflate' \
    --data '{
              "Type" : "Notification",
              "MessageId" : "4e7c1cc8-baa1-5e48-a7fd-4fe4caf5bddb",
              "TopicArn" : "arn:aws:sns:us-west-1:123073262904:mdw-lambda-autoscale-FgtScEvt",
              "Subject" : "Auto Scaling:  Lifecycle action 'LAUNCHING' for instance i-05884101f5458e202 in progress.",
              "Message" : "{\"LifecycleHookName\":\"mdw-lambda-autoscale-ASLifecycleLaunchHook-BTYDKUYDT6G6\",\"AccountId\":\"123073262904\",\"RequestId\":\"5ee58923-f5f7-b852-e05d-5ea5d2ae5218\",\"LifecycleTransition\":\"autoscaling:EC2_INSTANCE_LAUNCHING\",\"AutoScalingGroupName\":\"mdw-lambda-autoscale-ASG1-JDX8N4KR2HPN\",\"Service\":\"AWS Auto Scaling\",\"Time\":\"2018-03-21T14:37:08.270Z\",\"EC2InstanceId\":\"i-07babba9b2ebdcfa9\",\"LifecycleActionToken\":\"b77cc060-1d25-4d05-a75a-224c6f8e9fb5\"}",
              "Timestamp" : "2018-03-21T14:37:08.301Z",
              "SignatureVersion" : "1",
              "Signature" : "UrkMzq4Q1FqjijVLH5MWTY6dP80Q0HCbgiDLC9QbWp/kuYN13sOOiMCr/b73oqV80TuCOjNshgjMAVE/HwOgD8UmpxPQo7hscNbAWB8m1LJ4OHI57F0VYeU82Oz4xtVEjstYc9uzdXxfKgiEBS0xkF7EaOK/jNt2WZ4tzpQJVWPJA5J9KpXJ2DJ7CTq+J8NaKmYNjPyrCaKPSeUOJfMam1B4szigJgQ6LD5oUhGoXUyCMjPuKr5w9TvNNkOPpmE5xJ39WA8XlppOFAKuBhYpT1XVzP6yqYD5TsoJBoVt9IsaIjTceHaV9rXIcIHGzcv0ciN3fD3EQaV1zGqDrSsS7g==",
              "SigningCertURL" : "https://sns.us-west-1.amazonaws.com/SimpleNotificationService-433026a4050d206028891664da859041.pem",
              "UnsubscribeURL" : "https://sns.us-west-1.amazonaws.com/?Action=Unsubscribe&SubscriptionArn=arn:aws:sns:us-west-1:123073262904:mdw-lambda-autoscale-FgtScEvt:f9928bb5-06d3-4211-b7f4-2a33c0809da1"
            }'
}

send_launch ()
{
    curl -vik --request POST --url http://127.0.0.1:8000/sns \
    --header 'x-amz-sns-message-type: Notification' \
    --header 'x-amz-sns-message-id: 30e629d4-be84-45d9-8033-eec459d065a8' \
    --header 'x-amz-sns-topic-arn: arn:aws:sns:us-west-1:123073262904:mdw-lambda-autoscale-FgtScEvt' \
    --header 'x-amz-sns-subscription-arn: arn:aws:sns:us-west-1:123073262904:mdw-lambda-autoscale-FgtScEvt:047214ab-3110-428b-a931-0d79ffd68be0' \
    --header 'Content-Type: text/plain; charset=UTF-8' \
    --header 'Connection: Keep-Alive' \
    --header 'User-Agent: Amazon Simple Notification Service Agent' \
    --header 'Accept-Encoding: gzip,deflate' \
    --data '{
              "Type" : "Notification",
              "MessageId" : "0221e784-8c9c-540e-a135-b4afb071cb5b",
              "TopicArn" : "arn:aws:sns:us-west-1:123073262904:mdw-lambda-autoscale-FgtScEvt",
              "Subject" : "Auto Scaling: launch for group \"mdw-lambda-autoscale-ASG1-18JXD88M0VYOJ\"",
              "Message" : "{\"Progress\":50,\"AccountId\":\"123073262904\",\"Description\":\"Launching a new EC2 instance:i-014017810173c460f\",\"RequestId\":\"63c58911-32dd-8270-032d-76b509124bff\",\"EndTime\":\"2018-03-20T16:45:33.182Z\",\"AutoScalingGroupARN\":\"arn:aws:autoscaling:us-west-1:123073262904:autoScalingGroup:669d9f83-3c68-40e7-89e7-1fd0ec5afbe0:autoScalingGroupName/mdw-lambda-autoscale-ASG1-18JXD88M0VYOJ\",\"ActivityId\":\"63c58911-32dd-8270-032d-76b509124bff\",\"StartTime\":\"2018-03-20T16:45:01.152Z\",\"Service\":\"AWS Auto Scaling\",\"Time\":\"2018-03-20T16:45:33.182Z\",\"EC2InstanceId\":\"i-014017810173c460f\",\"StatusCode\":\"InProgress\",\"StatusMessage\":\"\",\"Details\":{\"Subnet ID\":\"subnet-d9dd4282\",\"Availability Zone\":\"us-west-1c\"},\"AutoScalingGroupName\":\"mdw-lambda-autoscale-ASG1-18JXD88M0VYOJ\",\"Cause\":\"At 2018-03-20T16:44:56Z a user request update of AutoScalingGroup constraints to min: 2, max: 5, desired: 2 changing the desired capacity from 0 to 2.  At 2018-03-20T16:44:59Z an instance was started in response to a difference between desired and actual capacity, increasing the capacity from 0 to 2.\",\"Event\":\"autoscaling:EC2_INSTANCE_LAUNCH\"}",
              "Timestamp" : "2018-03-20T16:45:33.214Z",
              "SignatureVersion" : "1",
              "Signature" : "PFiUxlEhdWzyfm+Ka4Ixm3l+l2ciA9/eeCkR7vD+iOobPHqZg7R/9fKnZi2gbJcyhVK8bOsHGSkMCeS1aNQfkqX+pJ4w/6H6iyiFMy9VDLenuZpKDjW2RLW4Fa8rb54k4NczgP1P/8CnIOPkcrfip43+0qXBGBZkmEvluZothkEmJOh9JRc47o47AiyzomWz/X9Lk9g4VlbxTgPwy/wdVSyq3HrsE+P//LAyc9vRzwNHFPBh/HM0Ntro2G9R/3j7U2Omfpm1/tW5+nr61nAFWLterIOfrXeC35KRNevLbq9Fw8W3pzH+fICuEBULXHhJul8w7m+r1XvAMBrYkLbW6g==",
              "SigningCertURL" : "https://sns.us-west-1.amazonaws.com/SimpleNotificationService-433026a4050d206028891664da859041.pem",
              "UnsubscribeURL" : "https://sns.us-west-1.amazonaws.com/?Action=Unsubscribe&SubscriptionArn=arn:aws:sns:us-west-1:123073262904:mdw-lambda-autoscale-FgtScEvt:047214ab-3110-428b-a931-0d79ffd68be0"
            }'
}

send_lch_terminate ()
{
    curl -vik --request POST --url http://127.0.0.1:8000/sns \
    --header 'x-amz-sns-message-type: Notification' \
    --header 'x-amz-sns-message-id: 30e629d4-be84-45d9-8033-eec459d065a8' \
    --header 'x-amz-sns-topic-arn: arn:aws:sns:us-west-1:123073262904:mdw-lambda-autoscale-FgtScEvt' \
    --header 'x-amz-sns-subscription-arn: arn:aws:sns:us-west-1:123073262904:mdw-lambda-autoscale-FgtScEvt:047214ab-3110-428b-a931-0d79ffd68be0' \
    --header 'Content-Type: text/plain; charset=UTF-8' \
    --header 'Connection: Keep-Alive' \
    --header 'User-Agent: Amazon Simple Notification Service Agent' \
    --header 'Accept-Encoding: gzip,deflate' \
    --data '{
              "Type" : "Notification",
              "MessageId" : "e3f44068-605b-5a3b-83d3-135e6c3f5caf",
              "TopicArn" : "arn:aws:sns:us-west-1:123073262904:mdw-lambda-autoscale-FgtScEvt",
              "Subject" : "Auto Scaling:  Lifecycle action 'TERMINATING' for instance i-0a035fc2897f9b3ea in progress.",
              "Message" : "{\"LifecycleHookName\":\"mdw-lambda-autoscale-ASLifecycleTerminateHook-PBSB6WCHB11E\",\"AccountId\":\"123073262904\",\"RequestId\":\"e31525b3-1640-42e5-a622-d2c9aed51464\",\"LifecycleTransition\":\"autoscaling:EC2_INSTANCE_TERMINATING\",\"AutoScalingGroupName\":\"mdw-lambda-autoscale-FgtScEvt\",\"Service\":\"AWS Auto Scaling\",\"Time\":\"2018-03-28T21:33:24.701Z\",\"EC2InstanceId\":\"i-0a035fc2897f9b3ea\",\"LifecycleActionToken\":\"238f84bb-2e05-4fe9-8b25-6bc58c05810e\"}",
              "Timestamp" : "2018-03-28T21:33:24.733Z",
              "SignatureVersion" : "1",
              "Signature" : "BckI4CG8BDgFfPRkAn41yMQ/WctkqbY4PCWcjLJifMLH9uUC3FY3gWILWhGOvPOrztuxT7gKY0vt2wttLjj4hw2MVy8ikjyi443GVMH0igYe68bmsIFi1PARnqKcP65uvm7A5Sw4mjziEKBepZQFkYJgbK6Ag2WBTC6EyDFXZiLxspcIIBfe/Z7hGVloSEuRf9+9ygr4ZoHsXKztxR27YRK7aOnQO3mX17c0Kj6A6lvVYHv005Q03dHIqu4Taq3kX+oPZ4m2S4CjweFQabsaWqcwoe4OzMgp+oX+TUG09glmF0f3WAQyTL22nZjkOCcHp/vKCPou2oFLxrUlQi9AgA==",
              "SigningCertURL" : "https://sns.us-west-1.amazonaws.com/SimpleNotificationService-433026a4050d206028891664da859041.pem",
              "UnsubscribeURL" : "https://sns.us-west-1.amazonaws.com/?Action=Unsubscribe&SubscriptionArn=arn:aws:sns:us-west-1:123073262904:mdw-lambda-autoscale-FgtScEvt:37b97b56-0f00-4403-b89f-a62d035bde8d"
            }'
}

send_terminate ()
{
    curl -vik --request POST --url http://127.0.0.1:8000/sns \
    --header 'x-amz-sns-message-type: Notification' \
    --header 'x-amz-sns-message-id: 30e629d4-be84-45d9-8033-eec459d065a8' \
    --header 'x-amz-sns-topic-arn: arn:aws:sns:us-west-1:123073262904:mdw-lambda-autoscale-FgtScEvt' \
    --header 'x-amz-sns-subscription-arn: arn:aws:sns:us-west-1:123073262904:mdw-lambda-autoscale-FgtScEvt:047214ab-3110-428b-a931-0d79ffd68be0' \
    --header 'Content-Type: text/plain; charset=UTF-8' \
    --header 'Connection: Keep-Alive' \
    --header 'User-Agent: Amazon Simple Notification Service Agent' \
    --header 'Accept-Encoding: gzip,deflate' \
    --data '{
              "Type" : "Notification",
              "MessageId" : "37cff84a-4065-5782-94cf-ab617e8d7337",
              "TopicArn" : "arn:aws:sns:us-west-1:123073262904:mdw-lambda-autoscale-FgtScEvt",
              "Subject" : "Auto Scaling: termination for group \"mdw-lambda-autoscale-ASG1-18JXD88M0VYOJ\"",
              "Message" : "{\"Progress\":50,\"AccountId\":\"123073262904\",\"Description\":\"Terminating EC2 instance: i-0e78823fc3a50c1a0\",\"RequestId\":\"bdbe100a-6069-4bb3-b3bf-c6dcd44bbc4f\",\"EndTime\":\"2018-03-20T16:54:00.468Z\",\"AutoScalingGroupARN\":\"arn:aws:autoscaling:us-west-1:123073262904:autoScalingGroup:669d9f83-3c68-40e7-89e7-1fd0ec5afbe0:autoScalingGroupName/mdw-lambda-autoscale-ASG1-18JXD88M0VYOJ\",\"ActivityId\":\"bdbe100a-6069-4bb3-b3bf-c6dcd44bbc4f\",\"StartTime\":\"2018-03-20T16:53:18.455Z\",\"Service\":\"AWS Auto Scaling\",\"Time\":\"2018-03-20T16:54:00.468Z\",\"EC2InstanceId\":\"i-0e78823fc3a50c1a0\",\"StatusCode\":\"InProgress\",\"StatusMessage\":\"\",\"Details\":{\"Subnet ID\":\"subnet-d9dd4282\",\"Availability Zone\":\"us-west-1c\"},\"AutoScalingGroupName\":\"mdw-lambda-autoscale-ASG1-18JXD88M0VYOJ\",\"Cause\":\"At 2018-03-20T16:52:52Z a user request update of AutoScalingGroup constraints to min: 0, max: 0, desired: 0 changing the desired capacity from 2 to 0.  At 2018-03-20T16:53:18Z an instance was taken out of service in response to a difference between desired and actual capacity, shrinking the capacity from 2 to 0.  At 2018-03-20T16:53:18Z instance i-082f42ded8f73a91f was selected for termination.  At 2018-03-20T16:53:18Z instance i-0e78823fc3a50c1a0 was selected for termination.\",\"Event\":\"autoscaling:EC2_INSTANCE_TERMINATE\"}",
              "Timestamp" : "2018-03-20T16:54:00.531Z",
              "SignatureVersion" : "1",
              "Signature" : "ECWxm212akG2RAP4rJeey4Z3UO8ldz5+VHEtMy+QSizXesTfEC3QVDM9ggNsY8JOCSePBV1sNlIYRRqh9rinVUtbh5UnrZnmcnhieYyKYkbvWbO4rLpWus2W5dfuAM8CTY48wb926Ixi9ql4Ji4tC4Fxks+bbf8rcrkXnNjJiyH6wbUTOeYOyPQAQ4WlNkU9+WPz2loZgEinWOvVyKXWk7k8Oe1hEPc8c05kyk0j7SaA4fJzZ4PEzQqWEvQuqjqznlEUG4wvgdhCoz2HWbLTQFWZuTv5/N0ilq7+vyivCOshf6Gc9B/RFsBVlRC2M6EjtJDxcOGKelgael5OSBGU9g==",
              "SigningCertURL" : "https://sns.us-west-1.amazonaws.com/SimpleNotificationService-433026a4050d206028891664da859041.pem",
              "UnsubscribeURL" : "https://sns.us-west-1.amazonaws.com/?Action=Unsubscribe&SubscriptionArn=arn:aws:sns:us-west-1:123073262904:mdw-lambda-autoscale-FgtScEvt:047214ab-3110-428b-a931-0d79ffd68be0"
            }'
}

send_notify ()
{
    curl -vik --request POST --url http://127.0.0.1:8000/sns \
    --header 'x-amz-sns-message-type: Notification' \
    --header 'x-amz-sns-message-id: 30e629d4-be84-45d9-8033-eec459d065a8' \
    --header 'x-amz-sns-topic-arn: arn:aws:sns:us-west-1:123073262904:mdw-lambda-autoscale-FgtScEvt' \
    --header 'x-amz-sns-subscription-arn: arn:aws:sns:us-west-1:123073262904:mdw-lambda-autoscale-FgtScEvt:047214ab-3110-428b-a931-0d79ffd68be0' \
    --header 'Content-Type: text/plain; charset=UTF-8' \
    --header 'Connection: Keep-Alive' \
    --header 'User-Agent: Amazon Simple Notification Service Agent' \
    --header 'Accept-Encoding: gzip,deflate' \
    --data '{
              "Type" : "Notification",
              "MessageId" : "1ea7fb50-7f0b-57d3-b6de-a87cade34aea",
              "TopicArn" : "arn:aws:sns:us-west-1:123073262904:mdw-lambda-autoscale-FgtScEvt",
              "Subject" : "Auto Scaling: test notification for group \"mdw-lambda-autoscale-ASG1-10GBWVR2OO5YS\"",
              "Message" : "{\"AccountId\":\"123073262904\",\"RequestId\":\"16dc73ed-2d50-11e8-859c-139362710439\",\"AutoScalingGroupARN\":\"arn:aws:autoscaling:us-west-1:123073262904:autoScalingGroup:842dbe8e-1c3b-412e-9c11-092d59df2f91:autoScalingGroupName/mdw-lambda-autoscale-ASG1-10GBWVR2OO5YS\",\"AutoScalingGroupName\":\"mdw-lambda-autoscale-ASG1-10GBWVR2OO5YS\",\"Service\":\"AWS Auto Scaling\",\"Event\":\"autoscaling:TEST_NOTIFICATION\",\"Time\":\"2018-03-21T21:37:43.954Z\"}",
              "Timestamp" : "2018-03-21T21:37:44.166Z",
              "SignatureVersion" : "1",
              "Signature" : "KBuAeg70RRtZ7ephlmeKyuLvcI/mO9ro5ceyR6r9QOOLI9WpfbhvG0CPoYHuU5g/aplTNH0H7ZlI2sR2y+Gx6pnaaHQw2DZBVd7zXaYIc5KfhIGXowUvg3e8hIBQfOzD/kmzoMUzYzccMNqynrdhEAgmeoC67Wy1K5oUUFopXaGUqcYucbSJGc3MK38JoK6j6C0aoC8Y10Mz3+kIhu7d820KZgGus+JuqmTOkOiCHjCEbgOPcLdJzUdW7wYflUXgSl//ypdk23fmXL14jBYZ19gUSN0UY44kh6VbnK28Mp9OqamLYmkdecEDt2cj3FjvaHDTIC1m2PrMSe/yLdpGWw==",
              "SigningCertURL" : "https://sns.us-west-1.amazonaws.com/SimpleNotificationService-433026a4050d206028891664da859041.pem",
              "UnsubscribeURL" : "https://sns.us-west-1.amazonaws.com/?Action=Unsubscribe&SubscriptionArn=arn:aws:sns:us-west-1:123073262904:mdw-lambda-autoscale-FgtScEvt:acf38e80-b9b4-4514-a7f4-b5bdb58cb9d3"
            }'

}

usage()
{
cat << EOF
usage: $0 options

This script will deploy a series of cloudformation templates that build and protect a workload

OPTIONS:
   -s send subscribe
   -n send notify
   -t send terminate
   -T send lifecycle hook terminate
   -l send launch
   -L send lifecycle hook launch
   -S send scheduled message
EOF
}

while getopts LlnsTtS OPTION
do
     case $OPTION in
         L)
             SEND_LCH_LAUNCH=true
             ;;
         l)
             SEND_LAUNCH=true
             ;;
         n)
             SEND_NOTIFY=true
             ;;
         S)
             SEND_SCHEDULED=true
             ;;
         s)
             SEND_SUBSCRIBE=true
             ;;
         T)
             SEND_LCH_TERMINATE=true
             ;;
         t)
             SEND_TERMINATE=true
             ;;
         ?)
             usage
             exit
             ;;
     esac
done

if [ "$SEND_SCHEDULED" == true ]
then
    send_scheduled
fi
if [ "$SEND_SUBSCRIBE" == true ]
then
    send_subscribe
fi
if [ "$SEND_NOTIFY" == true ]
then
    send_notify
fi
if [ "$SEND_LCH_LAUNCH" == true ]
then
    send_lch_launch
fi
if [ "$SEND_LAUNCH" == true ]
then
    send_launch
fi
if [ "$SEND_LCH_TERMINATE" == true ]
then
    send_lch_terminate
fi
if [ "$SEND_TERMINATE" == true ]
then
    send_terminate
fi
