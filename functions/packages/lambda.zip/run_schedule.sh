#!/bin/bash -vx
while true
do 
http http://127.0.0.1:8000/start <<HERE
{
"region":"us-east-1",
"stack":"mstack"
}
HERE
sleep 20
done
